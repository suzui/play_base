package interfaces;

public interface BaseEnum {
    public int code();
    
    public String intro();
}
