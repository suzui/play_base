git add -A;
git commit -m "m";
git push;
